
package com.foc.velocidadcorredor;


public class Main {

    public static void main(String[] args){
        
        CalculadoraTiempoCorredor corredor1 = new CalculadoraTiempoCorredor();
        
        corredor1.setDistancia(25); //En Kilometros
        corredor1.setVelocidad(6); //En Kilometros / Hora
        
        System.out.println("El Corredor 1, si corriera a una velocidad de " + corredor1.getVelocidad() + " km/h, durante " 
                + corredor1.getDistancia() + " km, tardaría apróximadamente " + corredor1.tiempoCorredor() + " horas" );
        
        
    }
    
    
    
    
}
