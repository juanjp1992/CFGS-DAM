
package com.foc.velocidadcorredor;

public class CalculadoraTiempoCorredor {
    //ATRIBUTOS
    private int velocidad;
    private int distancia;
    private double tiempo;
    
    //CONSTRUCTOR, PARA INICIALIZAR ATRIBUTOS

    public CalculadoraTiempoCorredor() {
        velocidad = 0;
        distancia = 0;
        tiempo = 0.0;
               
    }
    
    
    
    //GETTERS Y SETTERS

    public int getVelocidad() {
        return velocidad;
    }

    public void setVelocidad(int velocidad) {
        this.velocidad = velocidad;
    }

    public int getDistancia() {
        return distancia;
    }

    public void setDistancia(int distancia) {
        this.distancia = distancia;
    }

    public double getTiempo() {
        return tiempo;
    }

    public void setTiempo(double tiempo) {
        this.tiempo = tiempo;
    }
  
    public double tiempoCorredor(){
        
       tiempo = (double) distancia / velocidad;
       
      
               
        return tiempo;
    }
    
}
